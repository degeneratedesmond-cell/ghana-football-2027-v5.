extends RigidBody3D
class_name MatchBall

func _ready() -> void:
    mass = 0.45
    linear_damp = 0.65
    angular_damp = 0.8
    var sphere := SphereMesh.new()
    sphere.radius = 0.32
    sphere.height = 0.64
    var mesh := MeshInstance3D.new()
    mesh.mesh = sphere
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color.WHITE
    mat.roughness = 0.45
    mesh.material_override = mat
    add_child(mesh)
    var collision := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = 0.32
    collision.shape = shape
    add_child(collision)
    continuous_cd = true

func kick(direction: Vector3, power: float) -> void:
    apply_central_impulse(direction.normalized() * power)
