extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const BallScript = preload("res://scripts/ball.gd")
const FIELD_LENGTH := 100.0
const FIELD_WIDTH := 64.0
const TEAM_NAMES := ["GHANA BLACK STARS", "KUMASI UNITED", "ACCRA CITY", "BIBIANI FC", "ASHANTI WARRIORS"]

var players: Array[FootballPlayer] = []
var home_players: Array[FootballPlayer] = []
var away_players: Array[FootballPlayer] = []
var ball: MatchBall
var selected_player: FootballPlayer
var possession_team := 0
var home_score := 0
var away_score := 0
var match_seconds := 0.0
var match_length_seconds := 300.0
var match_finished := false
var match_started := false
var mode := "Friendly"
var home_team_name := "GHANA BLACK STARS"
var away_team_name := "KUMASI UNITED"
var difficulty := "Normal"
var hud: CanvasLayer
var score_label: Label
var timer_label: Label
var info_label: Label
var menu_layer: Control
var joystick_vector := Vector2.ZERO
var touch_sprint := false
var touch_shoot := false
var touch_pass := false
var touch_switch := false
var camera: Camera3D
var camera_pivot: Node3D
var career_data := {"matches": 0, "wins": 0, "draws": 0, "losses": 0, "points": 0, "season": 1}
var tournament_round := 1
var tournament_wins := 0
var home_choice: OptionButton
var away_choice: OptionButton
var difficulty_choice: OptionButton
var duration_choice: OptionButton

func _ready() -> void:
	_setup_input()
	_load_progress()
	_create_environment()
	_create_pitch()
	_create_players()
	_create_ball()
	_create_camera()
	_create_hud()
	_select_nearest_player()
	_show_main_menu()

func _process(delta: float) -> void:
	if match_started and not match_finished:
		match_seconds += delta
		if match_seconds >= match_length_seconds:
			_finish_match()
	_update_camera(delta)
	_update_hud()
	_handle_actions()

func _physics_process(_delta: float) -> void:
	if ball == null or not match_started or match_finished:
		return
	if ball.global_position.y < -4.0 or abs(ball.global_position.x) > FIELD_WIDTH * 0.5 + 2.0:
		_reset_ball()
		return
	if ball.global_position.z < -FIELD_LENGTH * 0.5:
		if abs(ball.global_position.x) < 3.75:
			home_score += 1
			_goal_scored(home_team_name)
		else:
			_reset_ball()
	elif ball.global_position.z > FIELD_LENGTH * 0.5:
		if abs(ball.global_position.x) < 3.75:
			away_score += 1
			_goal_scored(away_team_name)
		else:
			_reset_ball()
	if ball.linear_velocity.length() > 0.2:
		var nearest := _nearest_player_to_ball()
		if nearest and nearest.is_near_ball():
			possession_team = nearest.team

func _setup_input() -> void:
	_add_key("move_up", KEY_W)
	_add_key("move_down", KEY_S)
	_add_key("move_left", KEY_A)
	_add_key("move_right", KEY_D)
	_add_key("sprint", KEY_SHIFT)
	_add_key("shoot", KEY_SPACE)
	_add_key("pass", KEY_E)
	_add_key("switch_player", KEY_Q)
	_add_key("tackle", KEY_F)

func _add_key(action: String, key: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var event := InputEventKey.new()
	event.physical_keycode = key
	InputMap.action_add_event(action, event)

func _create_environment() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = Sky.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.65, 0.72, 0.82)
	env.ambient_light_energy = 0.7
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world.environment = env
	add_child(world)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	add_child(sun)

func _create_pitch() -> void:
	var grass := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(FIELD_WIDTH, FIELD_LENGTH)
	grass.mesh = plane
	var grass_mat := StandardMaterial3D.new()
	grass_mat.albedo_color = Color(0.08, 0.34, 0.13)
	grass_mat.roughness = 1.0
	grass.material_override = grass_mat
	grass.position.y = -0.08
	add_child(grass)
	for i in range(10):
		var stripe := MeshInstance3D.new()
		var stripe_mesh := PlaneMesh.new()
		stripe_mesh.size = Vector2(FIELD_WIDTH, 10.0)
		stripe.mesh = stripe_mesh
		var stripe_mat := StandardMaterial3D.new()
		stripe_mat.albedo_color = Color(0.10, 0.39, 0.15) if i % 2 == 0 else Color(0.07, 0.31, 0.12)
		stripe.material_override = stripe_mat
		stripe.position = Vector3(0, -0.065, -45.0 + i * 10.0)
		add_child(stripe)
	_line(Vector3(0, 0.015, 0), Vector3(FIELD_WIDTH, 0.015, 0), FIELD_WIDTH)
	_line(Vector3(0, 0.015, -50), Vector3(0, 0.015, 50), FIELD_LENGTH)
	_line(Vector3(-32, 0.015, -50), Vector3(32, 0.015, -50), 64)
	_line(Vector3(-32, 0.015, 50), Vector3(32, 0.015, 50), 64)
	_line(Vector3(-32, 0.015, 0), Vector3(32, 0.015, 0), 64)
	_circle_mark(Vector3(0, 0.02, 0), 9.15)
	for z_sign in [-1.0, 1.0]:
		var z := z_sign * 50.0
		var inner := z_sign * 34.0
		_line(Vector3(-20, 0.02, z), Vector3(20, 0.02, z), 40)
		_line(Vector3(-20, 0.02, inner), Vector3(20, 0.02, inner), 40)
		_line(Vector3(-20, 0.02, inner), Vector3(-20, 0.02, z), 16)
		_line(Vector3(20, 0.02, inner), Vector3(20, 0.02, z), 16)
	_goal_frame(0, -50)
	_goal_frame(0, 50)

func _line(a: Vector3, b: Vector3, length: float) -> void:
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(0.12, 0.035, length)
	mesh.mesh = box
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.92, 0.94, 0.86)
	mesh.material_override = mat
	mesh.position = (a + b) * 0.5
	if abs(b.x - a.x) > abs(b.z - a.z):
		mesh.rotation.y = PI * 0.5
	add_child(mesh)

func _circle_mark(center: Vector3, radius: float) -> void:
	for i in range(48):
		var a := TAU * float(i) / 48.0
		var b := TAU * float(i + 1) / 48.0
		_line(Vector3(center.x + cos(a) * radius, center.y, center.z + sin(a) * radius), Vector3(center.x + cos(b) * radius, center.y, center.z + sin(b) * radius), 0.9)

func _goal_frame(x: float, z: float) -> void:
	for pos in [Vector3(x - 3.66, 1.2, z), Vector3(x + 3.66, 1.2, z), Vector3(x, 2.44, z)]:
		var post := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(0.18, 2.5, 0.18) if pos.y < 2.0 else Vector3(7.5, 0.18, 0.18)
		post.mesh = box
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color.WHITE
		post.material_override = mat
		post.position = pos
		add_child(post)

func _create_players() -> void:
	var formation := [Vector3(0, 0, 43), Vector3(-25, 0, 34), Vector3(-9, 0, 35), Vector3(9, 0, 35), Vector3(25, 0, 34), Vector3(-17, 0, 17), Vector3(0, 0, 19), Vector3(17, 0, 17), Vector3(-12, 0, 5), Vector3(12, 0, 5), Vector3(0, 0, -2)]
	for team_id in [0, 1]:
		for i in range(11):
			var home: Vector3 = formation[i]
			if team_id == 1:
				home.z = -home.z
			var p: FootballPlayer = PlayerScript.new()
			p.setup(team_id, i + 1, home, self)
			add_child(p)
			players.append(p)
			if team_id == 0:
				home_players.append(p)
			else:
				away_players.append(p)
	selected_player = home_players[0]
	selected_player.controlled = true

func _create_ball() -> void:
	ball = BallScript.new()
	ball.position = Vector3(0, 0.35, 0)
	add_child(ball)

func _create_camera() -> void:
	camera_pivot = Node3D.new()
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0, 43, 48)
	camera.rotation_degrees = Vector3(-38, 0, 0)
	camera.fov = 48
	camera.current = true
	camera_pivot.add_child(camera)

func _update_camera(delta: float) -> void:
	if camera_pivot and ball:
		var focus := ball.global_position
		focus.y = 0
		camera_pivot.global_position = camera_pivot.global_position.lerp(focus, min(delta * 2.0, 1.0))

func _create_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var panel := PanelContainer.new()
	panel.position = Vector2(14, 12)
	panel.custom_minimum_size = Vector2(390, 76)
	hud.add_child(panel)
	var v := VBoxContainer.new()
	panel.add_child(v)
	score_label = Label.new()
	score_label.add_theme_font_size_override("font_size", 24)
	score_label.text = "BLACK STARS  0 - 0  OPPONENT"
	v.add_child(score_label)
	timer_label = Label.new()
	timer_label.text = "00:00 | FRIENDLY"
	v.add_child(timer_label)
	info_label = Label.new()
	info_label.position = Vector2(16, 92)
	info_label.text = "Move • Sprint • Pass • Shoot • Tackle • Switch"
	hud.add_child(info_label)
	_add_touch_button("PASS", Vector2(1030, 560), "pass")
	_add_touch_button("SHOOT", Vector2(1120, 470), "shoot")
	_add_touch_button("SPRINT", Vector2(1020, 640), "sprint")
	_add_touch_button("SWITCH", Vector2(1120, 640), "switch")
	_add_touch_button("TACKLE", Vector2(920, 560), "tackle")
	_add_touch_button("▲", Vector2(88, 555), "up")
	_add_touch_button("▼", Vector2(88, 645), "down")
	_add_touch_button("◀", Vector2(0, 600), "left")
	_add_touch_button("▶", Vector2(176, 600), "right")
	var pause_button := Button.new()
	pause_button.text = "PAUSE"
	pause_button.position = Vector2(1120, 14)
	pause_button.pressed.connect(_show_pause_menu)
	hud.add_child(pause_button)

func _add_touch_button(caption: String, pos: Vector2, action: String) -> void:
	var b := Button.new()
	b.text = caption
	b.position = pos
	b.custom_minimum_size = Vector2(86, 58)
	b.button_down.connect(func(): _set_touch(action, true))
	b.button_up.connect(func(): _set_touch(action, false))
	hud.add_child(b)

func _set_touch(action: String, value: bool) -> void:
	match action:
		"shoot": touch_shoot = value
		"pass": touch_pass = value
		"sprint": touch_sprint = value
		"switch": touch_switch = value
		"tackle":
			if value:
				_tackle()
		"up": joystick_vector.y = -1.0 if value else 0.0
		"down": joystick_vector.y = 1.0 if value else 0.0
		"left": joystick_vector.x = -1.0 if value else 0.0
		"right": joystick_vector.x = 1.0 if value else 0.0

func _update_hud() -> void:
	if score_label:
		score_label.text = "%s  %d - %d  %s" % [home_team_name, home_score, away_score, away_team_name]
		timer_label.text = "%02d:%02d | %s" % [int(match_seconds) / 60, int(match_seconds) % 60, mode.to_upper()]

func get_player_input() -> Vector3:
	var x := Input.get_action_strength("move_right") - Input.get_action_strength("move_left") + joystick_vector.x
	var z := Input.get_action_strength("move_down") - Input.get_action_strength("move_up") + joystick_vector.y
	var v := Vector3(x, 0, z)
	return v.normalized() if v.length() > 1.0 else v

func is_sprinting() -> bool:
	return Input.is_action_pressed("sprint") or touch_sprint

func _handle_actions() -> void:
	if not match_started or match_finished:
		return
	if Input.is_action_just_pressed("shoot") or touch_shoot:
		_shoot()
		touch_shoot = false
	if Input.is_action_just_pressed("pass") or touch_pass:
		_pass_ball()
		touch_pass = false
	if Input.is_action_just_pressed("switch_player") or touch_switch:
		_select_nearest_player()
		touch_switch = false
	if Input.is_action_just_pressed("tackle"):
		_tackle()

func _shoot() -> void:
	if selected_player and selected_player.global_position.distance_to(ball.global_position) < 3.0:
		var goal_dir := Vector3(0, 0.13, -1 if selected_player.team == 0 else 1)
		ball.kick(goal_dir, 22.0)
		possession_team = selected_player.team

func _pass_ball() -> void:
	if selected_player and selected_player.global_position.distance_to(ball.global_position) < 3.0:
		var teammate := _nearest_teammate()
		if teammate:
			var dir := teammate.global_position - ball.global_position
			dir.y = 0.12
			ball.kick(dir, 11.0)
			possession_team = selected_player.team

func _tackle() -> void:
	if selected_player and selected_player.global_position.distance_to(ball.global_position) < 2.5:
		ball.kick(selected_player.direction + Vector3.UP * 0.08, 7.0)

func _nearest_teammate() -> FootballPlayer:
	var best: FootballPlayer
	var best_d := INF
	for p in home_players:
		if p == selected_player:
			continue
		var d := p.global_position.distance_to(ball.global_position)
		if d < best_d:
			best_d = d
			best = p
	return best

func _nearest_player_to_ball() -> FootballPlayer:
	var best: FootballPlayer
	var best_d := INF
	for p in players:
		var d := p.global_position.distance_to(ball.global_position)
		if d < best_d:
			best_d = d
			best = p
	return best

func _select_nearest_player() -> void:
	if selected_player:
		selected_player.controlled = false
	var best: FootballPlayer
	var best_d := INF
	for p in home_players:
		var d := p.global_position.distance_to(ball.global_position)
		if d < best_d:
			best_d = d
			best = p
	selected_player = best
	if selected_player:
		selected_player.controlled = true

func _goal_scored(team_name: String) -> void:
	info_label.text = "GOAL! " + team_name
	_reset_ball()
	await get_tree().create_timer(1.5).timeout
	if match_started and not match_finished:
		info_label.text = "Move • Sprint • Pass • Shoot • Tackle • Switch"

func _reset_ball() -> void:
	ball.linear_velocity = Vector3.ZERO
	ball.angular_velocity = Vector3.ZERO
	ball.global_position = Vector3(0, 0.4, 0)
	for p in players:
		p.velocity = Vector3.ZERO

func _show_main_menu() -> void:
	match_started = false
	match_finished = false
	_show_menu_panel("GHANA FOOTBALL 2027 – V5", "Choose a game mode, teams and match settings.", true)

func _show_menu_panel(title_text: String, subtitle: String, setup: bool) -> void:
	if menu_layer:
		menu_layer.queue_free()
	menu_layer = Control.new()
	menu_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	menu_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	hud.add_child(menu_layer)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.04, 0.025, 0.88)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.add_child(shade)
	var panel := PanelContainer.new()
	panel.anchor_left = 0.18
	panel.anchor_right = 0.82
	panel.anchor_top = 0.08
	panel.anchor_bottom = 0.92
	menu_layer.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	panel.add_child(col)
	var title := Label.new()
	title.text = title_text
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 28)
	col.add_child(title)
	var desc := Label.new()
	desc.text = subtitle
	desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(desc)
	if setup:
		var modes := HBoxContainer.new()
		col.add_child(modes)
		for mode_name in ["Friendly", "Tournament", "Career"]:
			var mode_button := Button.new()
			mode_button.text = mode_name
			mode_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			mode_button.pressed.connect(func(): _choose_mode(mode_name))
			modes.add_child(mode_button)
		var home_label := Label.new()
		home_label.text = "HOME TEAM"
		col.add_child(home_label)
		home_choice = OptionButton.new()
		for team in TEAM_NAMES:
			home_choice.add_item(team)
		home_choice.select(0)
		col.add_child(home_choice)
		var away_label := Label.new()
		away_label.text = "AWAY TEAM"
		col.add_child(away_label)
		away_choice = OptionButton.new()
		for team in TEAM_NAMES:
			away_choice.add_item(team)
		away_choice.select(1)
		col.add_child(away_choice)
		var settings := HBoxContainer.new()
		col.add_child(settings)
		difficulty_choice = OptionButton.new()
		difficulty_choice.add_item("Easy")
		difficulty_choice.add_item("Normal")
		difficulty_choice.add_item("Hard")
		difficulty_choice.select(1)
		difficulty_choice.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		settings.add_child(difficulty_choice)
		duration_choice = OptionButton.new()
		duration_choice.add_item("3 minute match")
		duration_choice.add_item("5 minute match")
		duration_choice.add_item("10 minute match")
		duration_choice.select(1)
		duration_choice.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		settings.add_child(duration_choice)
		var career_label := Label.new()
		career_label.text = "CAREER: Season %d  |  Played %d  |  Wins %d  |  Points %d" % [career_data.season, career_data.matches, career_data.wins, career_data.points]
		career_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(career_label)
	if not setup and not match_finished:
		var resume := Button.new()
		resume.text = "RESUME MATCH"
		resume.pressed.connect(_resume_match)
		col.add_child(resume)
	var back := Button.new()
	back.text = "BACK TO MAIN MENU" if not setup else "START FRIENDLY"
	if setup:
		back.pressed.connect(func(): _start_match("Friendly"))
	else:
		back.pressed.connect(_show_main_menu)
	col.add_child(back)
	if not setup:
		var save_note := Label.new()
		save_note.text = "Your career and tournament progress are saved on this device."
		save_note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(save_note)

func _choose_mode(mode_name: String) -> void:
	_start_match(mode_name)

func _start_match(selected_mode: String) -> void:
	mode = selected_mode
	if home_choice:
		home_team_name = TEAM_NAMES[home_choice.selected]
	if away_choice:
		away_team_name = TEAM_NAMES[away_choice.selected]
	if home_team_name == away_team_name:
		away_team_name = TEAM_NAMES[(TEAM_NAMES.find(home_team_name) + 1) % TEAM_NAMES.size()]
	if difficulty_choice:
		difficulty = difficulty_choice.get_item_text(difficulty_choice.selected)
	if duration_choice:
		match_length_seconds = [180.0, 300.0, 600.0][duration_choice.selected]
	match_seconds = 0.0
	home_score = 0
	away_score = 0
	match_finished = false
	match_started = true
	possession_team = 0
	_reset_ball()
	for p in players:
		p.global_position = p.home_position
		p.velocity = Vector3.ZERO
	if menu_layer:
		menu_layer.queue_free()
		menu_layer = null
	info_label.text = "%s vs %s" % [home_team_name, away_team_name]

func _show_pause_menu() -> void:
	if not match_started or match_finished:
		return
	match_started = false
	_show_menu_panel("MATCH PAUSED", "Take a break or return to the main menu.", false)

func _resume_match() -> void:
	if menu_layer:
		menu_layer.queue_free()
		menu_layer = null
	match_started = true

func _finish_match() -> void:
	if match_finished:
		return
	match_finished = true
	match_started = false
	career_data.matches += 1
	if home_score > away_score:
		career_data.wins += 1
		career_data.points += 3
	elif home_score == away_score:
		career_data.draws += 1
		career_data.points += 1
	else:
		career_data.losses += 1
	if mode == "Tournament":
		if home_score > away_score:
			tournament_wins += 1
			tournament_round += 1
		_save_progress()
	elif mode == "Career":
		_save_progress()
	_save_progress()
	_show_result_menu()

func _show_result_menu() -> void:
	_show_menu_panel("FULL TIME: %d - %d" % [home_score, away_score], "%s vs %s  |  %s" % [home_team_name, away_team_name, mode], false)
	var col := menu_layer.get_child(1).get_child(0) as VBoxContainer
	var result := Label.new()
	result.text = "Career record: %d wins, %d draws, %d losses" % [career_data.wins, career_data.draws, career_data.losses]
	result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(result)
	var next := Button.new()
	next.text = "PLAY NEXT MATCH"
	next.pressed.connect(func(): _start_match(mode))
	col.add_child(next)

func _load_progress() -> void:
	var cfg := ConfigFile.new()
	if cfg.load("user://ghana_football_v5.cfg") == OK:
		for key in career_data.keys():
			career_data[key] = cfg.get_value("career", key, career_data[key])
		tournament_round = int(cfg.get_value("tournament", "round", 1))
		tournament_wins = int(cfg.get_value("tournament", "wins", 0))

func _save_progress() -> void:
	var cfg := ConfigFile.new()
	for key in career_data.keys():
		cfg.set_value("career", key, career_data[key])
	cfg.set_value("tournament", "round", tournament_round)
	cfg.set_value("tournament", "wins", tournament_wins)
	cfg.save("user://ghana_football_v5.cfg")
