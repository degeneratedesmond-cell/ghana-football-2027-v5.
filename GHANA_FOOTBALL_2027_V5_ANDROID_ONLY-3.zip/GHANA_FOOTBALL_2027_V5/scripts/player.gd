extends CharacterBody3D
class_name FootballPlayer

var team := 0
var shirt_number := 1
var controlled := false
var speed := 7.0
var sprint_speed := 10.0
var home_position := Vector3.ZERO
var target_position := Vector3.ZERO
var game
var body_mesh: MeshInstance3D
var direction := Vector3.FORWARD

func setup(team_id: int, number: int, home: Vector3, game_ref):
    team = team_id
    shirt_number = number
    home_position = home
    target_position = home
    game = game_ref
    name = ("Home_" if team == 0 else "Away_") + str(number)
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.8
    body_mesh = MeshInstance3D.new()
    body_mesh.mesh = capsule
    var material := StandardMaterial3D.new()
    material.albedo_color = Color(0.82, 0.12, 0.08) if team == 0 else Color(0.92, 0.92, 0.88)
    material.roughness = 0.8
    body_mesh.material_override = material
    body_mesh.position.y = 0.9
    add_child(body_mesh)
    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.4
    shape.height = 1.8
    collision.shape = shape
    add_child(collision)
    position = home

func _physics_process(delta: float) -> void:
    if game == null or game.match_finished or not game.match_started:
        velocity.x = move_toward(velocity.x, 0.0, 20.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 20.0 * delta)
        move_and_slide()
        return
    var move_dir := Vector3.ZERO
    if controlled:
        move_dir = game.get_player_input()
    else:
        target_position = _ai_target()
        var diff := target_position - global_position
        diff.y = 0
        if diff.length() > 0.25:
            move_dir = diff.normalized()
    var ai_boost := 1.0
    if not controlled and game.difficulty == "Hard":
        ai_boost = 1.15
    elif not controlled and game.difficulty == "Easy":
        ai_boost = 0.88
    var max_speed := (sprint_speed if controlled and game.is_sprinting() else speed) * ai_boost
    if move_dir.length() > 0.05:
        direction = move_dir.normalized()
        velocity.x = direction.x * max_speed
        velocity.z = direction.z * max_speed
        body_mesh.look_at(body_mesh.global_position + direction, Vector3.UP)
    else:
        velocity.x = move_toward(velocity.x, 0.0, 24.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 24.0 * delta)
    velocity.y -= 22.0 * delta
    move_and_slide()

func _ai_target() -> Vector3:
    var ball_pos: Vector3 = game.ball.global_position
    var attacking_sign := 1.0 if team == 0 else -1.0
    var dist_to_ball := global_position.distance_to(ball_pos)
    if team == game.possession_team and dist_to_ball < 24.0:
        return Vector3(ball_pos.x + (home_position.x * 0.08), 0, ball_pos.z + home_position.z * 0.08)
    if dist_to_ball < 13.0 and team != game.possession_team:
        return Vector3(ball_pos.x, 0, ball_pos.z)
    var advanced := home_position
    advanced.z -= attacking_sign * clamp(abs(ball_pos.z) * 0.18, 0.0, 8.0)
    return advanced

func is_near_ball() -> bool:
    return game != null and global_position.distance_to(game.ball.global_position) < 1.65
