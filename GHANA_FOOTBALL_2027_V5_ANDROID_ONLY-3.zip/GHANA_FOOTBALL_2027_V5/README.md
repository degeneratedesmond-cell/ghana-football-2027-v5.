# GHANA FOOTBALL 2027 – V5 Ultimate Android Edition

Godot 4 Android-only project for Android phones and tablets. Designed for landscape orientation and offline play. The project is a playable prototype foundation, not a finished commercial football game.

## V5 additions
- Main menu with Friendly, Tournament and Career entry points
- Team selection from five fictional Ghanaian clubs
- Easy / Normal / Hard opponent movement tuning
- 3, 5 or 10 minute match settings
- Match clock, scoreboard, goal detection limited to the goal mouth, pause and full-time screen
- Career record (matches, wins, draws, losses, points and season) saved locally using `user://ghana_football_v5.cfg`
- Tournament round and win counters saved locally
- Android touch controls, landscape layout and mobile-compatible GL renderer
- Android-only export preset for 32-bit and 64-bit ARM devices

## Important scope notes
- 22 players are procedural capsule placeholders; there are no licensed teams, player likenesses, real kits or motion-captured animations.
- Tournament progression currently tracks wins/rounds; it is not yet a complete league or cup bracket.
- Career currently records the player's results; transfers, contracts, training, fixtures and full season simulation are future work.
- AI, goalkeeper behavior, fouls, offsides, referees, replays, commentary and online play are not implemented.
- Graphics are a lightweight 3D prototype, not eFootball-level photorealism.
- APK and Android signing are not included; export from Godot on a computer after installing matching export templates and Android build tools.

## Open and run
1. Install Godot 4.3 or a compatible Godot 4 release.
2. Extract this folder and import `project.godot` in Godot Project Manager.
3. Open the project and press F6/F5 to run the main scene.
4. For Android export, install matching Godot export templates, JDK 17 and Android SDK build tools.
5. In Godot Editor Settings > Export > Android, set the Java SDK and Android SDK paths.
6. Open Project > Export, choose `Android Phones + Tablets`, then export to `build/GHANA_FOOTBALL_2027_V5_Android.apk`.

## Controls
- Touch: on-screen directional buttons, PASS, SHOOT, SPRINT, SWITCH, TACKLE and PAUSE.
- Keyboard during desktop editor testing: WASD move, Shift sprint, Space shoot, E pass, Q switch, F tackle.

## Project layout
- `project.godot` – project settings
- `scenes/main.tscn` – main game scene
- `scripts/game.gd` – match, menus, modes, save progress and HUD
- `scripts/player.gd` – player movement and simple AI
- `scripts/ball.gd` – ball physics
- `export_presets.cfg` – Android-only export preset
